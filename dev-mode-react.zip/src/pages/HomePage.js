import React from 'react';
import styled from 'styled-components';

const Container = styled.div`
  background: #f8f9fc;
  font-family: 'Pretendard', sans-serif;
  color: #111827;
`;

/* ────── Hero Section ────── */
const HeroSection = styled.section`
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: center;
  padding: 120px 40px 100px;
  max-width: 1280px;
  margin: 0 auto;
  gap: 40px;
`;

const HeroText = styled.div`
  flex: 1;
  min-width: 320px;
`;

const HeroTitle = styled.h1`
  font-size: 42px;
  font-weight: 800;
  line-height: 1.5;
  color: #1f2937;

  span {
    color: #6366f1;
  }
`;

const HeroDesc = styled.p`
  margin-top: 20px;
  font-size: 18px;
  color: #6b7280;
  line-height: 1.8;
`;

const ButtonGroup = styled.div`
  margin-top: 36px;
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
`;

const PrimaryButton = styled.button`
  background: #6366f1;
  color: white;
  padding: 14px 28px;
  font-size: 15px;
  font-weight: 600;
  border: none;
  border-radius: 10px;
  cursor: pointer;
`;

const SecondaryButton = styled.button`
  background: transparent;
  color: #6366f1;
  padding: 14px 28px;
  font-size: 15px;
  font-weight: 600;
  border: 2px solid #6366f1;
  border-radius: 10px;
  cursor: pointer;
`;

const HeroCard = styled.div`
  flex: 0.9;
  min-width: 300px;
  max-width: 400px;
  background: white;
  border-radius: 16px;
  box-shadow: 0 6px 20px rgba(0,0,0,0.05);
  padding: 28px;
`;

const CardHeader = styled.div`
  font-size: 13px;
  color: #4f46e5;
  font-weight: bold;
  margin-bottom: 8px;
`;

const CardTitle = styled.h3`
  font-size: 18px;
  font-weight: 700;
  margin-bottom: 16px;
`;

const CardBox = styled.div`
  background: #f3f4f6;
  border-radius: 10px;
  height: 100px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #9ca3af;
  font-size: 14px;
  margin-bottom: 16px;
`;

const CardFooter = styled.div`
  font-size: 13px;
  color: #6b7280;
  display: flex;
  justify-content: space-between;
`;

/* ────── Timeline Section ────── */
const StepContainer = styled.section`
  background: white;
  padding: 100px 20px;
  text-align: center;
`;

const StepTitle = styled.h2`
  font-size: 28px;
  font-weight: 700;
`;

const StepDesc = styled.p`
  margin-top: 12px;
  color: #6b7280;
  font-size: 16px;
  line-height: 1.6;
`;

const StepTimeline = styled.div`
  display: flex;
  justify-content: center;
  align-items: flex-start;
  position: relative;
  margin-top: 56px;
  gap: 16px;

  &::before {
    content: "";
    position: absolute;
    top: 55px;
    left: 5%;
    right: 5%;
    height: 2px;
    background: #e5e7eb;
    z-index: 0;
  }

  @media (max-width: 768px) {
    flex-direction: column;
    align-items: center;

    &::before {
      display: none;
    }
  }
`;

const StepItem = styled.div`
  background: white;
  z-index: 1;
  text-align: center;
  flex: 1;
  max-width: 180px;
  position: relative;
`;

const IconCircle = styled.div`
  width: 56px;
  height: 56px;
  background: #eef2ff;
  color: #6366f1;
  border-radius: 50%;
  margin: 0 auto 16px;
  font-size: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 4px rgba(0,0,0,0.08);
`;

const StepLabel = styled.div`
  font-weight: 700;
  font-size: 15px;
  margin-bottom: 8px;
`;

const StepText = styled.p`
  font-size: 13px;
  color: #6b7280;
  line-height: 1.5;
`;

const Connector = styled.span`
  position: absolute;
  top: 56px;
  right: -16px;
  color: #ccc;
  font-size: 20px;

  @media (max-width: 768px) {
    display: none;
  }
`;

/* ────── Why Us Section ────── */
const WhySection = styled.section`
  background: #f3f4f6;
  padding: 100px 20px;
  text-align: center;
`;

const FeatureGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
  max-width: 1200px;
  margin: 48px auto 0;

  @media (max-width: 1024px) {
    grid-template-columns: repeat(2, 1fr);
  }

  @media (max-width: 640px) {
    grid-template-columns: 1fr;
  }
`;

const FeatureCard = styled.div`
  background: white;
  border-radius: 16px;
  padding: 24px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.04);
  text-align: left;

  h4 {
    font-size: 16px;
    font-weight: 700;
    margin-bottom: 12px;
    color: #111827;
  }

  p {
    font-size: 14px;
    color: #6b7280;
    line-height: 1.5;
  }
`;

const HomePage = () => {
  const features = [
    { title: "블록체인으로 위변조 방지", desc: "기록된 유언장은 변경이 불가해 위변조 걱정이 없습니다." },
    { title: "법적 효력 연동", desc: "공증 및 인증 기관과 연동하여 법적 효력을 인정받습니다." },
    { title: "가족 간 분쟁 예방", desc: "명확하고 안전하게 전달되어 분쟁을 예방합니다." },
    { title: "암호화된 보안", desc: "블록체인 기반 저장과 암호화 열람으로 보안이 강화됩니다." },
    { title: "분산 저장 시스템", desc: "유언장을 안전하게 여러 네트워크에 분산 저장합니다." },
    { title: "유언장 접근 제한", desc: "열람 권한이 있는 사용자만 접근 가능하게 설정됩니다." },
  ];

  return (
    <Container>
      {/* Hero Section */}
      <HeroSection>
        <HeroText>
          <HeroTitle>
            당신의 마지막 뜻,<br />
            <span>안전하게 남기는</span> 가장 현대적인 방법.
          </HeroTitle>
          <HeroDesc>
            마침표는 블록체인 기반 유언장 공증 플랫폼입니다. <br />
            지정한 사람만 열람 가능한, 위조 걱정 없는 유언장을 남겨보세요.
          </HeroDesc>
          <ButtonGroup>
            <PrimaryButton>유언장 작성 시작하기</PrimaryButton>
            <SecondaryButton>서비스 소개 보기</SecondaryButton>
          </ButtonGroup>
        </HeroText>
        <HeroCard>
          <CardHeader>임시화면</CardHeader>
          <CardTitle>나의 마지막 유언장</CardTitle>
          <CardBox>블록체인으로 안전하게 보호됨</CardBox>
          <CardFooter>
            <div>지정 열람자: 3명</div>
            <div>공증 상태: 완료</div>
          </CardFooter>
        </HeroCard>
      </HeroSection>

      {/* Step Timeline Section */}
      <StepContainer>
        <StepTitle>서비스 작동 원리</StepTitle>
        <StepDesc>
          마침표는 최신 블록체인 기술을 활용하여 당신의 소중한 유언을 안전하게 보호하고 전달합니다.
        </StepDesc>
        <StepTimeline>
          <StepItem>
            <IconCircle>📄</IconCircle>
            <StepLabel>유언장 작성</StepLabel>
            <StepText>간단한 인터페이스를 통해 디지털 유언장을 작성합니다.</StepText>
            <Connector>→</Connector>
          </StepItem>
          <StepItem>
            <IconCircle>🖋️</IconCircle>
            <StepLabel>공증 연동</StepLabel>
            <StepText>블록체인 기술로 유언장의 진위와 법적 효력을 부여합니다.</StepText>
            <Connector>→</Connector>
          </StepItem>
          <StepItem>
            <IconCircle>👥</IconCircle>
            <StepLabel>열람자 지정</StepLabel>
            <StepText>귀하의 유언장을 열람할 수 있는 사람을 직접 지정합니다.</StepText>
            <Connector>→</Connector>
          </StepItem>
          <StepItem>
            <IconCircle>🔐</IconCircle>
            <StepLabel>사망 시 자동 열람</StepLabel>
            <StepText>사전 설정된 조건에 따라 지정된 사람에게만 유언장이 공개됩니다.</StepText>
          </StepItem>
        </StepTimeline>
      </StepContainer>

      {/* Why Us Section */}
      <WhySection>
        <StepTitle>왜 마침표인가요?</StepTitle>
        <StepDesc>
          신뢰할 수 있는 기술과 절차를 통해 삶의 마지막을 위한 최적의 유언 솔루션을 제공합니다.
        </StepDesc>
        <FeatureGrid>
          {features.map((item, i) => (
            <FeatureCard key={i}>
              <h4>{item.title}</h4>
              <p>{item.desc}</p>
            </FeatureCard>
          ))}
        </FeatureGrid>
      </WhySection>
    </Container>
  );
};

export default HomePage;
